# Deniz ve Gizem Rotam — Tam Sürüm 1.0

Bu paket demo değil, APK üretmeye hazır Android proje paketidir.

## Paket adı

`com.altayaytin.denizgizemrotam`

## Minimum Android

Android 8 / minSdk 26

## Özellikler

- Kotlin
- Jetpack Compose
- Material 3
- MVVM mantığı
- Retrofit
- Room altyapısı
- WorkManager
- Open-Meteo Weather API
- Open-Meteo Marine API
- Sığ/kumlu/az dalgalı plaj sıralama
- Takı bulma olasılığı: düşük / orta / yüksek
- Yasal uyarılar
- Ekonomik rota ve keşif rotası
- Bugünü Hafiflet
- Uygun yemek
- Tarih ve Gizem
- Ücretsiz konaklama
- Ucuz pansiyon ekranı
- Navigasyon, telefon, WhatsApp yönlendirme
- Açık/koyu tema
- Türkçe arayüz
- Birim testi
- GitHub Actions APK derleme

## Canlı veri

Hava, rüzgâr, yağmur, dalga ve deniz suyu sıcaklığı Open-Meteo üzerinden alınır.

## Uydurma bilgi yok

Pansiyon fiyatı, işletme fiyatı, kamp yasağı veya ziyaret durumu doğrulanamıyorsa uygulama bunu açıkça gösterir.

## APK derleme

GitHub Actions şu komutu çalıştırır:

```bash
./gradlew assembleDebug
```

Çıktı:

```text
app/build/outputs/apk/debug/app-debug.apk
```
