package com.altayaytin.denizgizemrotam

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScoringTest {
    @Test
    fun shallowSandyCalmBeachRanksHigh() {
        val beach = Beach(
            id = "test",
            name = "Test",
            region = "Test",
            latitude = 0.0,
            longitude = 0.0,
            bottom = "Kum",
            shallow = true,
            slowDeepening = true,
            usuallyCalm = true,
            free = true,
            crowd = 9,
            oldUse = true,
            beachClubDensity = 8,
            walkSearchSuitable = true
        )
        assertTrue(Scoring.beachScore(beach) >= 80)
        assertEquals(JewelryChance.HIGH, Scoring.jewelryChance(beach))
    }
}
